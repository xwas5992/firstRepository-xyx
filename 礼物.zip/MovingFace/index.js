$(document).ready(function(){
    $('#Mainbox').on('mousemove', function (event) {
        // 获取鼠标相对于元素的偏移位置
        const offsetX = event.offsetX;
        const offsetY = event.offsetY;
        // 构建位置信息字符串
        // const info = `鼠标在元素内的位置：X = ${offsetX}, Y = ${offsetY}`;
        // // 将位置信息更新到指定的 p 元素中
        // $('#elementPositionInfo').text(info);
        //根据鼠标的相对位置设置及一个坐标轴
        if(offsetX<340&&offsetX>0&&offsetY>0&&offsetY<190)//设置一象限
        {
            $("#showing").fadeOut("slow");
            $("#showing1").fadeIn("slow");
            $("#showing2").fadeOut("slow");
            $("#showing3").fadeOut("slow");
            $("#showing4").fadeOut("slow");
        }
        else if(offsetX<680&&offsetX>340&&offsetY>0&&offsetY<190)//设置二象限
        {
            $("#showing").fadeOut("slow");
            $("#showing1").fadeOut("slow");
            $("#showing2").fadeIn("slow");
            $("#showing3").fadeOut("slow");
            $("#showing4").fadeOut("slow");
        }
        else if(offsetX<340&&offsetX>0&&offsetY>190&&offsetY<380)//设置三象限
        {
            $("#showing").fadeOut("slow");
            $("#showing1").fadeOut("slow");
            $("#showing2").fadeOut("slow");
            $("#showing3").fadeIn("slow");
            $("#showing4").fadeOut("slow");
        }
        else if(offsetX<680&&offsetX>340&&offsetY>190&&offsetY<380)//设置四象限
        {
            $("#showing").fadeOut("slow");
            $("#showing1").fadeOut("slow");
            $("#showing2").fadeOut("slow");
            $("#showing3").fadeOut("slow");
            $("#showing4").fadeIn("slow");
        }
    });
    $("#yes").click(function(){
        alert("说出心声了吧");
    })
    $("#no").click(function(){
        alert("骗鬼呢，重选");
    })
});  